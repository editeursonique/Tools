from pystyle import *
import os
import subprocess
from colorama import *
import time
import requests
from discord_webhook import DiscordWebhook

def spam_webhook(webhook_url, bot_name, spam_text, num_spams):
    for _ in range(num_spams):
        payload = {"content": spam_text, "username": bot_name}
        requests.post(webhook_url, json=payload)

def spam_image_webhook(webhook_url, bot_name, image_path, num_spams):
    for _ in range(num_spams):
        webhook = DiscordWebhook(url=webhook_url, username=bot_name)

        # Chargez l'image depuis le chemin du fichier
        with open(image_path, "rb") as f:
            image_content = f.read()

        # Ajoutez l'image en tant que fichier attaché
        webhook.add_file(file=image_content, filename="spam_image.png")

        # Envoyez le message avec l'image
        webhook.execute()

def spam_embed_webhook(webhook_url, bot_name, num_spams):
    for _ in range(num_spams):
        # Créez un message avec une incorporation simple
        embed = {
    "title": "BALIZ TOOLS",
    "description": "MULTI TOOLS MAD BY POPEYEGTS AND UNKNOW FOR EDUCATION",
    "color": 65535,  # Couleur cyan (format décimal)
    "author": {
        "name": "Youtube Link Here",
        "url": "https://youtu.be/vRPV4jvpWsI",
        "icon_url": "https://image.shutterstock.com/image-photo/man-woman-kissing-hugging-romantic-260nw-1394683004.jpg"
    },
    "fields": [
        {"name": "1", "value": "NOT OUT YET", "inline": True},
        {"name": "2", "value": "NOT OUT YET", "inline": True},
        {"name": "3", "value": "NOT OUT YET", "inline": False}
    ],
    "footer": {
        "text": "The Menu Are Not Finished",
        "icon_url": "https://image.shutterstock.com/image-photo/man-woman-kissing-hugging-romantic-260nw-1394683004.jpg"
    }
}
        payload_embed = {
            "embeds": [embed],
            "username": bot_name
        }

        requests.post(webhook_url, json=payload_embed)

def is_valid_webhook(url):
    # Vous pouvez ajouter des vérifications supplémentaires ici
    return url.startswith("https://discord.com/api/webhooks/")

def contains_inappropriate_words(text):
    # Liste de mots inappropriés
    inappropriate_words = ["hitler", "nigga", "nigger"]
    for word in inappropriate_words:
        if word in text.lower():
            return True
    return False

os.system('clear' if os.name == 'posix' else 'cls')

intro = """
 ______        ___       __       __   ________  
|   _  \      /   \     |  |     |  | |       /  
|  |_)  |    /  ^  \    |  |     |  | `---/  /   
|   _  <    /  /_\  \   |  |     |  |    /  /    by Popeyegts & Unknow
|  |_)  |  /  _____  \  |  `----.|  |   /  /----.
|______/  /__/     \__\ |_______||__|  /________|
                 > Press Enter                                         
"""

Anime.Fade(Center.Center(intro), Colors.blue_to_green, Colorate.Vertical, interval=0.005, enter=True)

print(f"""{Fore.LIGHTRED_EX}
 ______        ___       __       __   ________  
|   _  \      /   \     |  |     |  | |       /  
|  |_)  |    /  ^  \    |  |     |  | `---/  /   
|   _  <    /  /_\  \   |  |     |  |    /  /    by Popeyegts & Unknow
|  |_)  |  /  _____  \  |  `----.|  |   /  /----.
|______/  /__/     \__\ |_______||__|  /________|
                 Welcome to BALIZ TOOLS
""")

time.sleep(1)

while True:
    Write.Print("\nWhich option do you want to choose: ", Colors.green_to_blue)
    Write.Print("\n1. Webhooks Spammer", Colors.blue_to_red)
    Write.Print("\n2. Image Spammer", Colors.blue_to_red)
    Write.Print("\n3. Embed Spammer", Colors.blue_to_red)
    Write.Print("\n4. Close", Colors.blue_to_green)
    Write.Print("\nMake your selection: ", Colors.red_to_green, end="")
    choice = input()

    if choice == "4":
        Write.Print("\nExiting the program...", Colors.red_to_green)
        break

    elif choice == "1":
        # Configuration du Webhook
        while True:
            webhook_url = input("\nEnter the Webhook URL: ")
            if is_valid_webhook(webhook_url):
                break
            else:
                Write.Print("\nInvalid webhook URL. Please enter a valid Discord webhook URL.", Colors.red_to_yellow)

        # Configuration du nom du bot
        bot_name = input("\nEnter the bot name: ")

        # Configuration du texte pour le spam
        while True:
            spam_text = input("\nEnter the text to spam: ")
            if not contains_inappropriate_words(spam_text):
                break
            else:
                Write.Print("\nText contains inappropriate words. Please enter a different text.", Colors.red_to_yellow)

        # Nombre de fois à spammer
        num_spams = int(input("\nEnter the number of times to spam: "))

        Write.Print("\nWebhook Spammer configured successfully!", Colors.blue_to_red)
        Write.Print("\nLaunching Webhook Spammer...", Colors.blue_to_red)

        # Code pour le spam
        spam_webhook(webhook_url, bot_name, spam_text, num_spams)

        Write.Print("\nSpamming complete!", Colors.blue_to_red)

    elif choice == "2":
        # Configuration du Webhook pour les images
        while True:
            webhook_url_image = input("\nEnter the Webhook URL: ")
            if is_valid_webhook(webhook_url_image):
                break
            else:
                Write.Print("\nInvalid webhook URL. Please enter a valid Discord webhook URL.", Colors.red_to_yellow)

        # Configuration du nom du bot pour les images
        bot_name_image = input("\nEnter the bot name: ")

        # Configuration du chemin de l'image
        image_path = input("\nEnter the path of the image to spam Exemple: ")

        # Vérifiez si le fichier d'image existe
        if not os.path.exists(image_path):
            Write.Print("\nImage file not found. Please enter a valid image file path.", Colors.red_to_yellow)
            continue

        # Configuration du nombre de fois à spammer l'image
        num_spams_image = int(input("\nEnter the number of times to spam the image: "))

        Write.Print("\nImage Webhook Spammer configured successfully!", Colors.blue_to_red)
        Write.Print("\nLaunching Image Webhook Spammer...", Colors.blue_to_red)

        # Code pour le spam d'image
        spam_image_webhook(webhook_url_image, bot_name_image, image_path, num_spams_image)

        Write.Print("\nImage spamming complete!", Colors.blue_to_red)

    elif choice == "3":
        # Configuration du Webhook pour les incorporations
        while True:
            webhook_url_embed = input("\nEnter the Webhook URL: ")
            if is_valid_webhook(webhook_url_embed):
                break
            else:
                Write.Print("\nInvalid webhook URL. Please enter a valid Discord webhook URL.", Colors.red_to_yellow)

        # Configuration du nom du bot pour les incorporations
        bot_name_embed = input("\nEnter the bot name: ")

        # Configuration du nombre de fois à spammer les incorporations
        num_spams_embed = int(input("\nEnter the number of times to spam the embeds: "))

        Write.Print("\nEmbed Webhook Spammer configured successfully!", Colors.blue_to_red)
        Write.Print("\nLaunching Embed Webhook Spammer...", Colors.blue_to_red)

        # Code pour le spam d'incorporations
        spam_embed_webhook(webhook_url_embed, bot_name_embed, num_spams_embed)

        Write.Print("\nEmbed spamming complete!", Colors.blue_to_red)

    else:
        Write.Print("\nYou have entered invalid. Please try again.", Colors.green_to_purple)
